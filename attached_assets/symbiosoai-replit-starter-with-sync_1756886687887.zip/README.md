# SymbiosoAi Replit Starter (React + Vite + Tailwind)

This is a ready-to-drop starter wired to **SymbiosoAi** tokens (colors, gradients, fonts).

## Quick Start (in Replit)
1. Create from this template or upload the zip.
2. Open the Shell and run:
   ```bash
   npm install
   npm run dev
   ```
3. Open the webview to see the hero, buttons, and cards.

## Tokens
- CSS variables: `tokens/variables.css` (imported globally in `src/styles/index.css`).
- Tailwind: `tailwind.config.js` extends with brand colors & radii.
- Design tokens JSON: `tokens/design-tokens.json` (for programmatic use).

## Dark Mode
Add `data-theme="dark"` on `<html>` or `<body>` to switch surfaces & text tokens.

## Fonts
Use **Montserrat** (headings) and **Inter** (body). Ensure they’re available on the machine or load via your preferred font host.
